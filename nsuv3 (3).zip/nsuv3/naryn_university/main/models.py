from django.db import models
from django.db import models

class Faculty(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField()
    image = models.ImageField(upload_to='faculties/', verbose_name='изображение')
class News(models.Model):
    title = models.CharField(max_length=100)
    content = models.TextField()
    image = models.ImageField(upload_to='news/', verbose_name='изображение')
def __str__(self):
    return self.name
from django.db import models

class Card(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField()
    image = models.ImageField(upload_to='cards/')
    pdf_file = models.FileField(upload_to='pdfs/')

    def __str__(self):
        return self.title
