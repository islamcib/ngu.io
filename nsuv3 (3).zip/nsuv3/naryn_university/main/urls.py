from django.urls import path
from .views import facultet_view  # Импортируем представление
from .views import leader_view  # Импортируем представление
from .views import card_page  # Импортируем представление
urlpatterns = [
    path('facultet/', faculties_view, name='facultet'),
    path('leader/', faculties_view, name='leader'),
    path('cards/', card_page, name='card_page'),
]
