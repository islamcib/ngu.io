# views.py
from django.shortcuts import render
from .models import Faculty
from .models import News
from .models import Card
def index(request):
    faculties = Faculty.objects.all()
    news_items = News.objects.all()  # Получаем все новости
    return render(request, 'index.html', {'faculties': faculties, 'news_items': news_items})


def facultet_view(request):
    return render(request, 'facultet.html')
def leader_view(request):
    return render(request, 'leader.html')


def card_page(request):
    cards = Card.objects.all()
    return render(request, 'card_page.html', {'cards': cards})