from django.contrib import admin
from .models import Faculty, News

from .models import Card

class CardAdmin(admin.ModelAdmin):
    list_display = ('title', 'description', 'image', 'pdf_file')
    search_fields = ('title', 'description')

admin.site.register(Card, CardAdmin)
@admin.register(Faculty)
class FacultyAdmin(admin.ModelAdmin):
    list_display = ('name', 'description', 'image')

    
@admin.register(News)
class NewsAdmin(admin.ModelAdmin):
    list_display = ('title', 'content', 'image')
    
