# urls.py
from django.contrib import admin
from django.urls import path
from main import views  # Импортируем views из нашего приложения
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.index, name='home'),  # Добавляем путь для главной страницы
    path('facultet/', views.facultet_view, name='facultet'),  # Правильный путь для 'facultet'
    path('leader/', views.leader_view, name='leader'),
    path('cards/', views.card_page, name='card_page'),
]

urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
